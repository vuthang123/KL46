Test results
============

Freescale has a complete test cycle for the BSP released. It
includes tests for Linux Kernel for the GPU package and for 
the VPU package (and all other package needed by the BSP, such as imx-lib).

The results and known issues, from Linux Kernel, GPU and VPU 
packages can be found in the Freescale Release Notes 
(Download tab of freescale.com/imx).

For boards from meta-freescale-3rdparty, the test cycle is performed by
each mantainer.
