.. include:: variables.inc

================
Acknowledgements
================

The FSL BSP Community is a community effort of keeping and mantaining
a Freescale boards/chips layer for the Yocto Project.

|release_name| Source Code
--------------------------

.. only:: html

   The following people helped to construct the source code for the release:

   .. literalinclude:: ack-sourcers.inc

.. only:: not html

   The statistics can be seen at the |project_name| website. It has
   not been included here as it changes every time bug fixes are
   included during the maintenance cycle of the release and it would
   be outdated most of time.
