.. _distros:

Distros
-------

The following distros are supported by FSL Community BSP.

.. include:: distro-list.inc

*NOTE: Poky's distros are still available to use.*
