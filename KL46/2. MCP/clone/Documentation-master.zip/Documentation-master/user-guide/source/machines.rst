.. _machines:

Machines
========

The scope of this release includes both meta-freescale and meta-freescale-3rdparty.
Please refer to the table below for the complete list of supported boards.


.. tabularcolumns:: c | p{5cm} | c | c
.. table:: Supported machines

   .. include:: ../../release-notes/source/machine-list.inc

